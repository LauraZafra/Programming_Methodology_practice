# OUTCOME OF TESTS FOR PROJECT imaging0

As of Feb  3 2022 07:10:24

| ID | NAME | RESULT | COMMENTS |
| :----- |:------ | :---: | :---: |
| 1::1 | _01_Basics.UnitByte_onBit | PASSED | OK |
| 1::2 | _01_Basics.UnitByte_onBit | PASSED | OK |
| 1::3 | _01_Basics.UnitByte_onBit | PASSED | OK |
| 2::1 | _01_Basics.UnitByte_offBit | PASSED | OK |
| 2::2 | _01_Basics.UnitByte_offBit | PASSED | OK |
| 2::3 | _01_Basics.UnitByte_offBit | PASSED | OK |
| 3::1 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::2 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::3 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::4 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::5 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::6 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::7 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::8 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::9 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::10 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::11 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::12 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::13 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::14 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::15 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 3::16 | _01_Basics.UnitByte_getBit | PASSED | OK |
| 4::1 | _01_Basics.UnitByte_to_string | PASSED | OK |
| 4::2 | _01_Basics.UnitByte_to_string | PASSED | OK |
| 5::1 | _01_Basics.UnitByte_shiftRByte | PASSED | OK |
| 5::2 | _01_Basics.UnitByte_shiftRByte | PASSED | OK |
| 5::3 | _01_Basics.UnitByte_shiftRByte | PASSED | OK |
| 6::1 | _01_Basics.UnitByte_shiftLByte | PASSED | OK |
| 6::2 | _01_Basics.UnitByte_shiftLByte | PASSED | OK |
| 6::3 | _01_Basics.UnitByte_shiftLByte | PASSED | OK |
| 7::1 | _01_Basics.INTEGRATION_Byte | PASSED | OK |
| 8::1 | _02_Intermediate.UnitByte_onByte | PASSED | OK |
| 9::1 | _02_Intermediate.UnitByte_offByte | PASSED | OK |
| 10::1 | _03_Advanced.UnitByte_encodeByte | PASSED | OK |
| 11::1 | _03_Advanced.UnitByte_decodeByte | PASSED | OK |
| 11::2 | _03_Advanced.UnitByte_decodeByte | PASSED | OK |
| 11::3 | _03_Advanced.UnitByte_decodeByte | PASSED | OK |
| 11::4 | _03_Advanced.UnitByte_decodeByte | PASSED | OK |
| 11::5 | _03_Advanced.UnitByte_decodeByte | PASSED | OK |
| 12::1 | _03_Advanced.UnitByte_decomposeByte | PASSED | OK |
| 12::2 | _03_Advanced.UnitByte_decomposeByte | PASSED | OK |
| 12::3 | _03_Advanced.UnitByte_decomposeByte | PASSED | OK |
| 12::4 | _03_Advanced.UnitByte_decomposeByte | PASSED | OK |
