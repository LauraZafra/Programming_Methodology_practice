/**
 * @file main.cpp
 * @author MP
 */
#include <iostream>
#include <cstring>
#include "MPTools.h"
#include "Byte.h"
#include "Image.h"
#include "Histogram.h"

using namespace std;

/**
 * @brief It waits until the key [INTRO] [RETURN] is pressed
 */
void pressReturnToContinue();

/**
 * @brief It breaks the program due to some error and shows a message
 * @param errorcode The type of error as declared in Image.h
 * @param errordata A message trying to describe the error
 */
void errorBreak(int errorcode, const string & errordata);

#define MAXCOLLECTION 10
int main() {

    Image im_input,im_histogram;
    Image im_collection [MAXCOLLECTION];
    Histogram histogram;
    int nimages=0, result;
    string input;
    
//    input="./data/checkers.pgm";
    input="./data/burgerking.pgm";
//    input="./data/playstation.pgm";
//    input="./data/missing.pgm";
//    input="./data/badformat.pgm";
//    input="./data/baddata.pgm";
//    input="./data/toolarge.pgm";
    result=im_input.readFromFile(input.c_str());
 


    im_input.showInWindow("input");
    cout << input << endl;
//  Image::inspect();


    pressReturnToContinue();
    return 0;
}


void pressReturnToContinue() {
    char aux[10];
    cout << "Press [RETURN] to continue ...";
    cin.getline(aux, 1, '\n');
}

void errorBreak(int errorcode, const string & errordata) {
    switch (errorcode) {
        case Image::IMAGE_ERROR_OPEN:
            cout << endl << "Error opening file " << errordata << endl;
            break;
        case Image::IMAGE_ERROR_DATA:
            cout << endl << "Data error in file " << errordata << endl;
            break;
        case Image::IMAGE_ERROR_FORMAT:
            cout << endl << "Unrecognized format in file " << errordata << endl;
            break;
        case Image::IMAGE_TOO_LARGE:
            cout << endl << "The image is too large and does not fit into memory" << errordata << endl;
            break;
    }
    std::exit(1);
}
